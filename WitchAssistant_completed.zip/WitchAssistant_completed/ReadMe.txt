WitchGPT is just a simple application. In the beginning, I wanted to make a sound-recognizing program to use a visual avatar for ChatGPT, but it was an overwhelmingly complex task for my skills.
I succeeded in to sound perceiving function, but calling animation was not done appropriately.  

Therefore, I just added simple functions :

1. WitchGPT helps to open ChatGPT.
2. WitchGPT helps to check Google Calendar.
3. date and time(yes it's just a clock.)

When your cursor is on the application window, the animation is swapped to the talking animation; otherwise, it just stays in the blinking idle state.

---------how to use----------------------
Install the Balgruf font first. 
Install talk-to-ChatGPT.

Execute WitchAssistant !! I hope this application helps to alleviate your life's pain and boredom. 